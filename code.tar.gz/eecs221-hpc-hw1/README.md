Group Members:
1. Vivek Narayanamurthy (23123110) - vpnaraya@uci.edu
2. Sriram Vamsi Ilapakurthy (78605368) - silapaku@uci.edu

We ran the program on the Intel8 cores.

We implemented the approach that was mention in the class.
1. Recursively calling the parallel mergesort method.
2. For merging two sorted arrays say A and B, we are using the binary search logic to divide B. Later we are recursively merging the the parts of A and B. 

We obtained the results lesser than the sequential one. I have attached the output files.
